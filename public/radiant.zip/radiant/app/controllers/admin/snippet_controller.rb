class Admin::SnippetController < Admin::AbstractModelController
  model_class Snippet
end