# Be sure to restart your web server when you modify this file.

# Radiant Gem Version
RADIANT_GEM_VERSION = '<%= Radiant::Version %>'

<%= File.open(radiant_environment).read %>
