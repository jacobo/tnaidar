require 'routing_extension'
require 'view_paths_extension'
require 'mailer_view_paths_extension'