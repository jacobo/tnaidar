# For some reason 1.1 forgot to require "stringio". This causes problems for schema.rb
require 'stringio'